P5 Joker 0.9.18 完整包（云端编译，源码提交 48c8a8c0，含华丽收场＝大罪穿甲弹的全部最新特效）。
安装：先退出游戏，把 P5Joker 文件夹里的 3 个文件（P5Joker.dll / P5Joker.json / P5Joker.pck）
复制到 <游戏目录>\mods\P5Joker\ 覆盖同名文件。覆盖前建议把原来的 mods\P5Joker 文件夹复制一份做备份。

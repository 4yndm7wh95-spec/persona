P5 Joker 0.9.11 combat fixes — 增量测试包

这不是完整资源包。需要现有 0.9.10 的 P5Joker.pck。
包含：P5Joker/P5Joker.dll 与 P5Joker/P5Joker.json；不含 PCK。
保留已安装的 P5Joker.pck，只更新 DLL 和清单。Codex 没有修改游戏目录、没有自动安装或启动游戏。
本版明确将 affects_gameplay 标记为 true，因为改变了 Joker 毒性爆发各目标的中毒结算顺序（并发启动）。数值、毒层衰减和触媒循环沿用原版。
完整说明及验证边界见同提交 docs/codex/reports/p5_combat_fixes_20261104/README.md。
